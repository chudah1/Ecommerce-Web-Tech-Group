<!DOCTYPE html>
<html>
<head>
  
  <title>Ratings</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="assets/img/apple-icon.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico"> <!-- change Favicon here-->

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">

    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">

</head>
<body >
  <div class="ratings-body">
                <a href="index.php">
                <button type="button" class="btn-close btn-close-black" aria-label="Close"></button></a>
              
                    <table>
                        <thead>
                            <tr>
                                <th scope="col"></th>
                                <th scope="col">Product</th>
                                <th scope="col"></th>

                        
                            </tr>
                        </thead>
                        <tbody>
                            <!--Item 1-->
                            <tr>
                                <td class="w-25">
                                    <img src="https://s3.eu-central-1.amazonaws.com/bootstrapbaymisc/blog/24_days_bootstrap/vans.png" class="img-fluid img-thumbnail" alt="Sheep">
                                </td>
                                <td>
                                    <p class="vertical_align">Vans Sk8-Hi MTE Shoes</p>
                                </td>
                                <td>
                                  
                                   <div class="rating">
                <input type="radio" id="star5" name="rating" value="5"><label for="star5" title="Great">5 stars</label>
                <input type="radio" id="star4" name="rating" value="4"><label for="star4" title="Good">4 stars</label>
                <input type="radio" id="star3" name="rating" value="3"><label for="star3" title="Okay">3 stars</label>
                <input type="radio" id="star2" name="rating" value="2"><label for="star2" title="Bad">2 stars</label>
                <input type="radio" id="star1" name="rating" value="1"><label for="star1" title="Very Bad">1 star</label>
              </div>
                                      
                                </td>
                        
                                
                            </tr>
                            
                            
                        </tbody>
                    </table>

</div>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="./assets/js/script.js"></script>
<script src="js/addons/rating.js"></script>

</body>
</html>